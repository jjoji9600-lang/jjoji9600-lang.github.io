"""第9周选做：先确认费用，再安全输入 Key。不保存 Key。"""
import getpass
import json
import urllib.error
import urllib.request

BASE = "https://api.deepseek.com"
def request(key, path, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(BASE + path, data=data,
        headers={"Authorization":"Bearer "+key, "Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=45) as response:
        raw=response.read(1_000_001)
    if len(raw)>1_000_000:
        raise ValueError("回复过大，请停止本次练习。")
    return json.loads(raw)

def main():
    print("这是可选的在线练习。办公软件会员不等于 DeepSeek API 余额。")
    print("先在官方平台看价格与余额。本程序最多发送一次聊天请求，不自动重试。")
    if input("愿意继续并承担 API 费用？输入 YES，其他内容都退出：").strip() != "YES":
        print("已退出，没有调用 API。")
        return 0
    key = getpass.getpass("粘贴你的学习专用 API Key 后按回车（屏幕不显示字符）：").strip()
    if not key:
        print("没有输入 Key，已退出。")
        return 1
    try:
        result=request(key,"/models")
        models=[item["id"] for item in result["data"]]
        if not models:
            raise ValueError("账户没有返回可用模型。")
        print("以下是服务返回的模型，请按官方文档选择支持聊天补全的模型：")
        for number,model in enumerate(models,1): print(number,model)
        choice=int(input("输入模型前面的数字；输入 0 取消："))
        if choice==0:
            print("已取消，没有发送聊天请求。")
            return 0
        if not 1<=choice<=len(models):
            raise ValueError("数字不在列表中。")
        model=models[choice-1]
        print("将使用模型：",model)
        if input("确认只发一次短请求？输入 YES：").strip()!="YES":
            print("已取消，没有发送聊天请求。")
            return 0
        result=request(key,"/chat/completions",{
            "model":model,"messages":[{"role":"user","content":"请用一句中文向初学者问好。"}],
            "max_tokens":128,"stream":False})
        print("模型回复：", result["choices"][0]["message"]["content"])
        print("服务返回的用量：",json.dumps(result.get("usage",{}),ensure_ascii=False))
        print("练习结束。本程序没有把 Key 保存到文件。费用请以平台账单为准。")
        return 0
    except urllib.error.HTTPError as e:
        print("没有成功，HTTP 状态码：",e.code,"。请按课程排查，不要连续重试。")
    except (urllib.error.URLError,TimeoutError,OSError):
        print("网络或等待时间出问题，请先停止，检查网络与平台状态。")
    except (ValueError,KeyError,IndexError,TypeError):
        print("模型选择或返回格式不符合预期，请检查官方文档，不要反复付费尝试。")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
