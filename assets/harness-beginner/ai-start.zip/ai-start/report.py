"""第5周使用：只读取本文件夹的模拟表格，不联网。"""
import csv
from pathlib import Path

FOLDER = Path(__file__).resolve().parent

def read_requests(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if reader.fieldnames != ["序号", "问题", "状态", "分钟"]:
            raise ValueError("表头不对，请使用原来的四列。")
        rows = list(reader)
    if not rows:
        raise ValueError("表格没有记录。")
    seen = set()
    for row in rows:
        if set(row) != {"序号", "问题", "状态", "分钟"} or any(v is None for v in row.values()):
            raise ValueError("某一行缺列或多列了。")
        if not row["序号"] or row["序号"] in seen:
            raise ValueError("序号为空或重复。")
        seen.add(row["序号"])
        if row["状态"] not in {"已完成", "待处理"}:
            raise ValueError("状态只能是已完成或待处理。")
        try:
            row["分钟"] = int(row["分钟"])
        except ValueError:
            raise ValueError("分钟必须是整数。") from None
        if row["分钟"] < 0:
            raise ValueError("分钟不能是负数。")
    return rows

def summarize(rows):
    return {
        "总条数": len(rows),
        "已完成": sum(row["状态"] == "已完成" for row in rows),
        "待处理": sum(row["状态"] == "待处理" for row in rows),
        "总分钟": sum(row["分钟"] for row in rows),
    }

def render(result):
    return "模拟求助周报\n" + "\n".join(f"{key}：{value}" for key, value in result.items()) + "\n"

def main():
    try:
        rows = read_requests(FOLDER / "requests.csv")
        text = render(summarize(rows))
        out = FOLDER / "weekly.txt"
        out.write_text(text, encoding="utf-8")
        print("成功：已经生成 weekly.txt，请双击打开核对。")
        print(text)
        return 0
    except (OSError, ValueError) as error:
        print("没有生成新的周报：", error)
        print("如原有 weekly.txt，它可能是旧文件，不代表本次成功。")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
