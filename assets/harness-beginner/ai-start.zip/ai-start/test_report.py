import tempfile
import unittest
from pathlib import Path
from report import read_requests, summarize, render, FOLDER

class ReportTests(unittest.TestCase):
    def test_original_numbers(self):
        self.assertEqual(summarize(read_requests(FOLDER / "requests.csv")),
            {"总条数":5, "已完成":3, "待处理":2, "总分钟":60})
    def test_changed_minutes(self):
        rows = read_requests(FOLDER / "requests.csv")
        rows[0]["分钟"] = 20
        self.assertEqual(summarize(rows)["总分钟"], 70)
    def check_bad(self, text):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/"bad.csv"
            path.write_text(text,encoding="utf-8")
            with self.assertRaises(ValueError): read_requests(path)
    def test_negative_minutes(self):
        self.check_bad("序号,问题,状态,分钟\n1,测试,已完成,-1\n")
    def test_wrong_status(self):
        self.check_bad("序号,问题,状态,分钟\n1,测试,不知道,10\n")
    def test_duplicate_id(self):
        self.check_bad("序号,问题,状态,分钟\n1,测试,已完成,10\n1,测试,待处理,10\n")
    def test_report_text(self):
        self.assertIn("总分钟：60", render(summarize(read_requests(FOLDER/"requests.csv"))))

if __name__ == "__main__":
    unittest.main()
