# DSH 受控任务卡

## 只读调查
确认当前工作区为 harness-lab，只读 README、需求与模拟 CSV。
不运行命令、不联网、不读凭证、不写文件。报告计划与缺失信息。

## 执行统计
经人工批准后运行 python -m src.report --dry-run。
检查退出码与真值，再批准生成 output/weekly.md。
失败停止，不用旧产物伪装成功，不自动提交、推送或外发。

## API 分类
单独请求人工授权在线调用与费用；Key 不进入会话。
python -m src.classify --live 只有在已配置环境的终端由人执行。
检查退出码、产物时间与 schema，再运行 python -m src.evaluate。

## 注意
这些任务卡不是权限隔离。工具权限与受限账户仍需实际配置。
本包的 CLI 是确定性工具和单轮分类请求，不是自研完整 DSH。
