import json
import unittest
from pathlib import Path
from unittest.mock import patch
from src import report
from src.classify import validate_result, classify
from src.api_client import api_request, chat, ApiError
from src.evaluate import score

class CoreTests(unittest.TestCase):
    def test_fixture(self):
        self.assertEqual(report.summarize(report.read_rows("tickets.csv")),
            {"total":12,"closed":8,"minutes":360,
             "by_department":{"ops":4,"sales":4,"support":4}})
    def test_traversal(self):
        with self.assertRaises(ValueError):
            report.inside(report.DATA,"../.env")
    def test_absolute_path(self):
        with self.assertRaises(ValueError):
            report.inside(report.DATA, str(Path.home()/"not-allowed"))
    def test_missing_file(self):
        with self.assertRaises(OSError):
            report.read_rows("missing.csv")
    def test_invalid_csv(self):
        with patch.object(Path,"stat") as st, patch.object(Path,"open") as op:
            import io
            st.return_value.st_size=100
            op.return_value.__enter__.return_value=io.StringIO("wrong,columns\n1,2\n")
            with self.assertRaises(ValueError): report.read_rows("bad.csv")
    def test_valid_schema(self):
        self.assertEqual(len(validate_result({"items":[{"id":"T01","category":"access"}]},["T01"])),1)
    def test_bad_label(self):
        with self.assertRaises(ValueError):
            validate_result({"items":[{"id":"T01","category":"admin"}]},["T01"])
    def test_duplicate(self):
        with self.assertRaises(ValueError):
            validate_result({"items":[{"id":"T01","category":"access"}]*2},["T01","T02"])
    def test_missing_item(self):
        with self.assertRaises(ValueError): validate_result({"items":[]},["T01"])
    def test_extra_fields(self):
        with self.assertRaises(ValueError):
            validate_result({"items":[],"command":"delete"},[])
    def test_non_string_label(self):
        with self.assertRaises(ValueError):
            validate_result({"items":[{"id":"T01","category":[]}]},["T01"])
    def test_fake_transport(self):
        def fake(messages):
            self.assertEqual(len(messages),2)
            return '{"items":[{"id":"T01","category":"other"}]}', {"total_tokens":5}
        self.assertEqual(classify([{"id":"T01","text":"hello"}],fake)["usage"]["total_tokens"],5)
    def test_malformed_json(self):
        with self.assertRaises(ValueError):
            classify([{"id":"T01","text":"hello"}],lambda m:("not json",{}))
    def test_no_key(self):
        with patch.dict("os.environ",{},clear=True):
            with self.assertRaises(ApiError): api_request("/models")
    def test_no_model(self):
        with patch.dict("os.environ",{},clear=True):
            with self.assertRaises(ApiError): chat([])
    def test_score(self):
        value={"items":[{"id":"T01","category":"other"}]}
        self.assertEqual(score(value,value)["accuracy"],1.0)

if __name__ == "__main__":
    unittest.main()
