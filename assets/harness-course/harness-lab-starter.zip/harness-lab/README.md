# Harness Lab：12 周练习包
Python 3.10+，只用标准库。所有工单均为模拟数据。先读课程，不要直接接入真实业务。
本包包含参考实现；学习时先自己做，卡住再比较，不要照抄后声称独立完成。

## 离线起步
在本目录打开终端：

```powershell
python --version
python -m unittest discover -s tests -v
python -m src.report --dry-run
python -m src.report
```

预期：16 个测试通过；总条数 12、已关闭 8、总分钟 360、每部门 4。
输出 output/weekly.md。退出码检查：PowerShell 用 $LASTEXITCODE，macOS/Linux 用 echo $?。

## 可选在线（仅第 4 周后）
先在系统终端设置 DEEPSEEK_API_KEY，禁止把真实值写进文档。

```powershell
python -m src.api_client --models
# 将你账户实际可用的模型 ID 设置到 DEEPSEEK_MODEL，再运行：
python -m src.api_client --ping
python -m src.classify --live
python -m src.evaluate
```

.env.example 仅作说明；本项目不自动读取 .env。
API 请求有真实费用，按平台当期价格。--live 只执行一轮分类，不自动重试。
结构校验失败不会写入新结果；旧 output/labels.json 可能仍存在，评测前确认文件来自本次运行。
单次 max_tokens 只限制输出，不是账户级预算；输入、思考等计费以官方说明为准。
不在日志中记录密钥与输入正文。此练习没有真实 OS 沙箱，不可直接用于生产。

## DSH 使用
见 docs/dsh-task-cards.md；Skill 草稿位于 docs/skill-draft/。
工作助手只协助学习；DSH + DeepSeek API 是主线。
不得将离线 fake 测试当作真实模型效果。
