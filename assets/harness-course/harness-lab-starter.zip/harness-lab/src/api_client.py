"""One request only. No automatic retry, no secret/content logging."""
import argparse
import json
import os
import urllib.error
import urllib.request

BASE_URL = "https://api.deepseek.com"
class ApiError(RuntimeError):
    pass

def api_request(path, payload=None):
    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not key:
        raise ApiError("missing_api_key")
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(BASE_URL + path, data=data,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=45) as response:
            raw = response.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ApiError("response_too_large")
        return json.loads(raw)
    except urllib.error.HTTPError as e:
        raise ApiError("http_" + str(e.code)) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ApiError("network_or_timeout") from None
    except (ValueError, UnicodeError):
        raise ApiError("invalid_response_json") from None

def chat(messages):
    model = os.environ.get("DEEPSEEK_MODEL", "").strip()
    if not model:
        raise ApiError("missing_model")
    response = api_request("/chat/completions", {
        "model": model, "messages": messages, "max_tokens": 512, "stream": False})
    try:
        content = response["choices"][0]["message"]["content"]
        usage = response.get("usage", {})
        if not isinstance(content, str) or not isinstance(usage, dict):
            raise ValueError()
        return content, usage
    except (KeyError, IndexError, TypeError, ValueError):
        raise ApiError("invalid_chat_response") from None

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--models", action="store_true")
    p.add_argument("--ping", action="store_true")
    args = p.parse_args()
    try:
        if args.models:
            result = api_request("/models")
            print("\n".join(item["id"] for item in result["data"]))
        elif args.ping:
            content, usage = chat([{"role": "user", "content": "只回答 OK"}])
            print(content)
            print(json.dumps({"usage": usage}, ensure_ascii=False))
        else:
            p.print_help()
    except (ApiError, KeyError, TypeError):
        print("api_failed: check key, model, balance, network or response format")
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
