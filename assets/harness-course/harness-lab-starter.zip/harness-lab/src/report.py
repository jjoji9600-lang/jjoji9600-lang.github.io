import argparse
import csv
import json
import os
import tempfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUTPUT = ROOT / "output"
FIELDS = ["id", "department", "status", "minutes", "text"]

def inside(root, name):
    root = root.resolve()
    path = (root / name).resolve()
    if not path.is_relative_to(root):
        raise ValueError("path_outside_allowed_directory")
    return path

def read_rows(name):
    path = inside(DATA, name)
    if path.stat().st_size > 1_000_000:
        raise ValueError("file_too_large")
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            raise ValueError("invalid_columns")
        rows = list(reader)
    if not rows or len(rows) > 1000:
        raise ValueError("invalid_row_count")
    seen = set()
    for row in rows:
        if set(row) != set(FIELDS) or any(v is None for v in row.values()):
            raise ValueError("invalid_row")
        if not row["id"] or row["id"] in seen:
            raise ValueError("duplicate_or_empty_id")
        seen.add(row["id"])
        if row["department"] not in {"sales", "support", "ops"}:
            raise ValueError("invalid_department")
        if row["status"] not in {"open", "closed"}:
            raise ValueError("invalid_status")
        try:
            minutes = int(row["minutes"])
        except ValueError:
            raise ValueError("invalid_minutes") from None
        if minutes < 0 or minutes > 1440:
            raise ValueError("invalid_minutes")
        row["minutes"] = minutes
        if len(row["text"]) > 2000:
            raise ValueError("text_too_long")
    return rows

def summarize(rows):
    return {
        "total": len(rows),
        "closed": sum(r["status"] == "closed" for r in rows),
        "minutes": sum(r["minutes"] for r in rows),
        "by_department": dict(sorted(Counter(r["department"] for r in rows).items())),
    }

def atomic_write(name, text):
    path = inside(OUTPUT, name)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return path

def render(stats):
    return ("# 工单周报\n\n"
            f"- 总工单：{stats['total']}\n"
            f"- 已关闭：{stats['closed']}\n"
            f"- 总处理分钟：{stats['minutes']}\n\n"
            "## 按部门\n\n" +
            "\n".join(f"- {k}: {v}" for k, v in stats["by_department"].items()) + "\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="tickets.csv")
    parser.add_argument("--out", default="weekly.md")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    try:
        stats = summarize(read_rows(args.input))
        if args.dry_run:
            print(json.dumps(stats, ensure_ascii=False, sort_keys=True))
        else:
            path = atomic_write(args.out, render(stats))
            print("report_written:", path.relative_to(ROOT))
    except (ValueError, OSError):
        print("report_failed: check input schema and allowed paths")
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
