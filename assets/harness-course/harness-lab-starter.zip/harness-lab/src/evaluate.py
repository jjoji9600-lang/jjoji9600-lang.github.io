import argparse
import json
from .report import ROOT, inside, OUTPUT

def score(gold, result):
    from .classify import validate_result
    expected = {x["id"]: x["category"] for x in gold["items"]}
    items = validate_result(result, list(expected))
    correct = sum(x["category"] == expected[x["id"]] for x in items)
    return {"correct": correct, "total": len(expected), "accuracy": correct / len(expected)}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--result", default="labels.json")
    args = p.parse_args()
    try:
        gold = json.loads((ROOT/"evals/gold.json").read_text(encoding="utf-8"))
        result = json.loads(inside(OUTPUT,args.result).read_text(encoding="utf-8"))
        if set(result) == {"items", "usage"}:
            result = {"items": result["items"]}
        print(json.dumps(score(gold,result),ensure_ascii=False))
    except (ValueError,OSError,TypeError):
        print("evaluation_failed: invalid or missing result")
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
